# simpleonepagewebsite
1stop.ai capstone project 1 frontend

## This is a simple One Page Website For Hotel booking System
### Tech Stack : Html, CSS, Javascript and Bootstrap
